<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <!-- Bootstrap CDN -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <!-- Font awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
</head>
<body>

<?php
session_start();
$count = 0;
if(isset($_SESSION['cart'])){
$count = count($_SESSION['cart']);
}
?>
<nav class="navbar bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold text-primary"><img src="logo2.png" height="40px"> AMANTRA</a>
    
    <div class="d-flex">

    
    <a href="index.php" class="text-primary text-decoration-none pe-2"><i class="fas fa-home"></i>Home</a>
    <a href="viewCart.php" class="text-primary text-decoration-none pe-2"><i class="fas fa-shopping-cart"></i>Cart(<?php echo $count?>) |</a>

    <span class="text-primary pe-2">
        <i class="fas fa-user-shield"></i>Hello, 
        <?php
if(isset($_SESSION['user'])){
    echo $_SESSION['user'];
echo " | <a href='form/logout.php' class='text-primary text-decoration-none pe-2'><i class='fas fa-sign-in-alt'></i>Logout</a>";
}
else{
echo "| <a href='form/login.php' class='text-primary text-decoration-none pe-2'><i class='fas fa-sign-in-alt'></i>Login</a>";

}
?>
|


<a href="../admin/mystore.php" class="text-primary text-decoration-none pe-2">Admin</a>
    </span>

  
</nav>
</div>

<div class="bg-primary sticky-top">
    <ul class="list-unstyled d-flex justify-content-center">
        <li>
            <a href="laptop.php" class="text-decoration-none px-5 fw-bold text-white fs-4">LAPTOP</a>
            <a href="mobile.php" class="text-decoration-none px-5 fw-bold text-white fs-4">MOBILE</a>
            <a href="bag.php" class="text-decoration-none px-5 fw-bold text-white fs-4">BAG</a>
            <a href="men.php" class="text-decoration-none px-5 fw-bold text-white fs-4">MEN</a>
        </li>
    </ul>
</div>
</body>
</html>
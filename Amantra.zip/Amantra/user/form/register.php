<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6 m-auto mt-5 bg-white shadow border border-info">

                <p class="text-primary fs-3 fw-bold my-3 text-center">User Registration</p>
                <form action="insert.php" method="post">
                    <div class="mb-3">
                        <label for="">Username:</label>
                        <input type="text" name = "name" placeholder = "Enter Username" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="">Email:</label>
                        <input type="email" name = "email" placeholder = "Enter User Email" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="">User Number:</label>
                        <input type="number" name = "number" placeholder = "Enter User number" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="">Password:</label>
                        <input type="password" name = "password" placeholder = "Enter Userpassword" class="form-control">
                    </div>
                    <div class="mb-3">
                        <button name = "Submit" class="w-100 bg-primary fs-4 text-white border-primary">REGISTER</button>
                    </div>
                    <div class="mb-3">
                        <button class="w-100 bg-primary fs-4 text-white border-primary"><a href="login.php" class="text-white text-decoration-none">Already have an account?</a></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
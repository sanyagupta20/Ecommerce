<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous"></head>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
<body class="text-center">
    <div class="container">
        <div class="row">
            <div class="col-md-5 m-auto border border-primary mt-3">

    <form action="insert.php" method="post" enctype="multipart/form-data">
    <div class="mb-3">
<p class="text-center fw-bold fs-3 text-primary">Product Detail</p>
</div>
<div class="mb-3">
  <label class="form-label">Product Name:</label>
  <input type="text" name="Pname" class="form-control" placeholder="Enter Product name">
</div>

<div class="mb-3">
  <label class="form-label">Product Price:</label>
  <input type="text" name="Pprice"class="form-control" placeholder="Enter Product price">
</div>

<div class="mb-3">
  <label class="form-label">Add Product Image:</label>
  <input type="file" name="Pimage" class="form-control">
</div>

<div class="mb-3">
  <label class="form-label">Select Page Category</label>
  <select class="form-select" name="Pages">
  <option value="Home">Home</option>
  <option value="Mens wear">Mens wear</option>
  <option value="Laptop">Laptop</option>
  <option value="Bag">Bag</option>
  <option value="Mobile">Mobile</option>
</select>
</div>
<button name="Submit"class="bg-primary fs-4 fw-bold my-3 form-control text-white">Upload</button>
    </form>
</div> 
</div> 
</div>

<div class="container">
<div class="row">
  <div class="col-md-6 m-auto">

  
<table class="table border border-primary table-hover border my-5">
  <thead class="bg-dark text-white fs-5 text-center">
    <th>ID</th>
    <th>Name</th>
    <th>Price</th>
    <th>Image</th>
    <th>Category</th>
    <th>Delete</th>
    <th>Update</th>
  </thead>

  <tbody>
    <?php
    include 'Config.php';
    $Record = mysqli_query($con, "SELECT * FROM `tblproduct`");
     while($row = mysqli_fetch_array($Record))
echo"
<tr>
<td>$row[id]</td>
<td>$row[PName]</td>
<td>$row[PPrice]</td>
<td><img src='$row[PImage]' height='80px' width='80px'></td>
<td>$row[PCategory]</td>
<td><a href='delete.php? ID=$row[id]' class = 'btn btn-primary'>Delete</a></td>
<td><a href='update.php? ID=$row[id]' class = 'btn btn-primary'>Update</a></td>
</tr>
";
    ?>
  </tbody>
</table>
</div>
</div>
</div>
</body>

</html>